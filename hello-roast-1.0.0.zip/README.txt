Hello Roast - test mod for RoastEngine.
If you can read this inside mods/hello-roast/ then downloading,
unzipping and scanning all worked.
